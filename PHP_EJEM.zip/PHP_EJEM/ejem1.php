<?php
echo "<h1>Impresión por pantalla (echo y print), (var_dump y print_r) </h1>";
// Ejemplo de echo  print
echo "Hola Mundo"; // echo puede tomar múltiples parámetros

echo "<br>Hola", " ", "Mundo", "\n";

print "<br> Hola Mundo\n"; // print solo puede tomar un parámetro

// var_dump y print_r
$array = ['manzana', 'naranja', 1, 2.5, true];
echo "<br>Usando var_dump:<br>";
var_dump($array); // Muestra tipo de dato y estructura

echo "<br>Usando print_r:<br>";
print_r($array); // Muestra estructura más legible

?>