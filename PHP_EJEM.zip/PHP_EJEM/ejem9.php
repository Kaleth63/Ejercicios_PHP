<?php
global$menu; global$config;
// 1. Ejemplo de include
// Si el archivo no existe, genera una advertencia (warning) pero el script continúa
echo "1. Usando include:<br>";
include 'funciones.php';
echo saludar("Juan") . "<br>";

// 2. Ejemplo de require
// Si el archivo no existe, genera un error fatal y detiene el script
echo "<br>2. Usando require:<br>";
require 'configuracion.php';
echo "Host de la base de datos: " . $config['db_host'] . "<br>";

// 3. Ejemplo de include_once
// Garantiza que el archivo solo se incluya una vez
echo "<br>3. Usando include_once:<br>";
include_once 'menu.php';
include_once 'menu.php'; // Esta segunda inclusión será ignorada
foreach ($menu as $nombre => $url) {
    echo "$nombre: $url<br>";
}

// 4. Ejemplo de require_once
// Similar a include_once pero con require
echo "<br>4. Usando require_once:<br>";
require_once 'funciones.php';
require_once 'funciones.php'; // Esta segunda inclusión será ignorada
echo saludar("María") . "<br>";

// 5. Ejemplo de manejo de errores con include
echo "<br>5. Probando include con archivo inexistente:<br>";
include 'archivo_no_existe.php'; // Generará warning pero continuará
echo "Este mensaje se mostrará a pesar del error<br>";

// 6. Ejemplo de manejo de errores con require
echo "<br>6. Probando require con archivo inexistente:<br>";
// La siguiente línea generaría un error fatal y detendría el script
// require 'archivo_no_existe.php';
echo "Este mensaje no se mostraría si el require anterior fallara<br>";
?>