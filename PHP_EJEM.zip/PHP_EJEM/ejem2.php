<?php
// Declaración de tipo estricto (fuerte tipado)
declare(strict_types=1);

// Declaración de constantes
const PI = 3.14159;
define('SALUDO', 'Hola Mundo');

// Variables con tipado débil (PHP por defecto)
$nombre = "Juan";           // string
$edad = 25;                // integer
$precio = 19.99;           // float
$activo = true;            // boolean

// Variables con tipo declarado (tipado fuerte)
function sumarNumeros(int $a, int $b): int {
    return $a + $b;
}

// Imprimir por pantalla
echo "<center><br>--- Constantes --->";
echo "<br>PI: " . PI . "";
echo "<br>SALUDO: " . SALUDO . "</center>";

echo "<center><br>--- Variables con tipado débil --->";
echo "<br>Nombre: " . $nombre . " (Tipo: " . gettype($nombre) . ")";
echo "<br>Edad: " . $edad . " (Tipo: " . gettype($edad) . ")\n";
echo "<br>Precio: " . $precio . " (Tipo: " . gettype($precio) . ")\n";
echo "<br>Activo: " . ($activo ? 'true' : 'false') . " (Tipo: " . gettype($activo) . ")</center>";

echo "<center><br>--- Ejemplo de tipado fuerte ---\n";
try {
    echo "<br>Suma de 5 + 3: " . sumarNumeros(5, 3) . "<br>";
    // Esto generará un error debido a strict_types=1
    echo sumarNumeros (5, (int)"3");
} catch (TypeError $e) {
    echo "Error de tipo: " . $e->getMessage() . "</center>";
}
?>