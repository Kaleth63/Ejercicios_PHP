<?php

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Ejemplos PHP</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .ejemplo { 
            background: #ffff; 
            padding: 15px; 
            margin: 10px 0; 
            border-radius: 5px; 
        }
        .resultado { 
            background: #e0ffe0; 
            padding: 10px; 
            margin-top: 5px; 
        }
    </style>
</head>
<body>
    <h1>Ejemplos de PHP</h1>

    <div class="ejemplo">
        <h3>1. Manejo de Impresión</h3>
        <?php
        echo "<div class='resultado'>";
        
        echo "Usando echo: Hola Mundo<br>";
        print "Usando print: Hola Mundo<br>";
        
        $array = ['manzana', 'naranja', 1, 2.5, true];
        echo "Usando var_dump:<br>";
        var_dump($array);
        
        echo "<br>Usando print_r:<br>";
        print_r($array);
        
        echo "</div>";
        ?>
    </div>

    <div class="ejemplo">
        <h3>2. Variables y Constantes</h3>
        <?php
        echo "<div class='resultado'>";
        
        $nombre = "Juan";
        $edad = 25;
        define('PI', 3.14159);
        const MAX_USERS = 100;
        
        echo "Variable nombre: $nombre<br>";
        echo "Variable edad: $edad<br>";
        echo "Constante PI: " . PI . "<br>";
        echo "Constante MAX_USERS: " . MAX_USERS;
        
        echo "</div>";
        ?>
    </div>

    <div class="ejemplo">
        <h3>3. Arrays</h3>
        <?php
        echo "<div class='resultado'>";
        
        // Array indexado
        $frutas = ['manzana', 'naranja', 'plátano'];
        echo "Array indexado:<br>";
        print_r($frutas);
        
        // Array asociativo
        $persona = [
            'nombre' => 'María',
            'edad' => 30,
            'ciudad' => 'Bogotá'
        ];
        echo "<br><br>Array asociativo:<br>";
        print_r($persona);
        
        echo "</div>";
        ?>
    </div>

    <div class="ejemplo">
        <h3>4. Funciones</h3>
        <?php
        echo "<div class='resultado'>";
        
        function saludar($nombre) {
            return "¡Hola, $nombre!";
        }
        
        echo saludar("Carlos") . "<br>";
        
        // Función con tipado
        function suma(int $a, int $b): int {
            return $a + $b;
        }
        
        echo "Suma: " . suma(5, 3);
        
        echo "</div>";
        ?>
    </div>

    <div class="ejemplo">
        <h3>5. Formulario de Prueba (POST)</h3>
        <form method="post" action="">
            <input type="text" name="nombre" placeholder="Ingresa tu nombre">
            <input type="submit" value="Enviar">
        </form>
        <?php
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['nombre'])) {
            echo "<div class='resultado'>";
            echo "Nombre recibido: " . htmlspecialchars($_POST['nombre']);
            echo "</div>";
        }
        ?>
    </div>

</body>
</html>