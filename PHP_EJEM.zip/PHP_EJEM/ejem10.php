<?php
// Ejemplo de uso de $_POST
echo "1. Ejemplo de POST:<br>";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    echo "Nombre: $nombre<br>Email: $email<br>";
} else {
    echo "Por favor, completa el formulario.<br>";
}

// Ejemplo de uso de $_GET
echo "<br>2. Ejemplo de GET:<br>";
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $page = isset($_GET['page']) ? $_GET['page'] : 1;
    echo "ID: $id<br>Página: $page<br>";
} else {
    echo "No se ha proporcionado un ID en la URL.<br>";
}

// Ejemplo de uso de $_FILES
echo "<br>3. Ejemplo de FILES:<br>";
if (isset($_FILES['archivo'])) {
    $archivo = $_FILES['archivo'];
    $destino = 'uploads/' . basename($archivo['name']);
    if (move_uploaded_file($archivo['tmp_name'], $destino)) {
        echo "Archivo subido correctamente: " . $archivo['name'] . "<br>";
    } else {
        echo "Error al subir el archivo.<br>";
    }
} else {
    echo "No se ha enviado ningún archivo.<br>";
}

// Ejemplo de uso de $_REQUEST
echo "<br>4. Ejemplo de REQUEST:<br>";
if (isset($_REQUEST['dato'])) {
    $dato = $_REQUEST['dato'];
    echo "Dato recibido: $dato<br>";
} else {
    echo "No se ha proporcionado el parámetro 'dato'.<br>";
}

// Ejemplo de uso de $_SESSION
echo "<br>5. Ejemplo de SESSION:<br>";
session_start();
$_SESSION['usuario'] = 'Juan';
echo "Usuario guardado en sesión: " . $_SESSION['usuario'] . "<br>";

// Ejemplo de uso de $_COOKIE
echo "<br>6. Ejemplo de COOKIE:<br>";
setcookie('visitas', 1, time() + 3600); // Expira en 1 hora
if (isset($_COOKIE['visitas'])) {
    $visitas = $_COOKIE['visitas'];
    echo "Número de visitas: $visitas<br>";
} else {
    echo "No se han encontrado cookies.<br>";
}
