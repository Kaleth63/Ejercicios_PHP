<?php
// TIPOS DE DATOS BÁSICOS
echo "<center>=== TIPOS DE DATOS BÁSICOS ===</center><br>";

// Boolean
$bool_true = true;
$bool_false = false;
echo "Boolean true: " . var_export($bool_true, true) . "<br>";
echo "Boolean false: " . var_export($bool_false, true) . "<br><br>";

// Integer
$entero = 42;
$entero_negativo = -17;
echo "Integer: $entero<br>";
echo "Integer negativo: $entero_negativo<br><br>";

// Float
$float = 3.14159;
$scientific = 2.5e3; // 2500
echo "Float: $float<br>";
echo "Notación científica: $scientific<br>";
echo "NaN: " . NAN . "<br><br>";

// String
$string = "Hola Mundo";
$string_comilla = 'PHP es genial';
echo "String 1: $string<br>";
echo "String 2: $string_comilla<br><br>";

// Null
$nulo = null;
echo "Valor nulo: " . var_export($nulo, true) . "<br><br>";

// Object
class Persona {
    public $nombre;
    public $edad;

    public function __construct($nombre, $edad) {
        $this->nombre = $nombre;
        $this->edad = $edad;
    }
}

$persona = new Persona("Juan", 25);
echo "Objeto Persona: ";
print_r($persona);
echo "<br>";

// ARRAYS
echo "<center><br>=== ARRAYS ===<br></center>";

// Array indexado
$frutas = ["manzana", "naranja", "plátano"];
echo "Array indexado:<br>";
print_r($frutas);

// Array asociativo
$persona_array = [
    "nombre" => "María",
    "edad" => 30,
    "ciudad" => "Madrid"
];
echo "<br>Array asociativo:<br>";
print_r($persona_array);

// Array multidimensional
$matriz = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9]
];
echo "<br>Array multidimensional:<br>";
print_r($matriz);

// ITERABLES
echo "<center><br>=== ITERABLES ===</center><br>";

// Iterar array indexado
echo "Iterando array indexado:<br>";
foreach ($frutas as $fruta) {
    echo "- $fruta<br>";
}

// Iterar array asociativo
echo "<br>Iterando array asociativo:<br>";
foreach ($persona_array as $clave => $valor) {
    echo "$clave: $valor<br>";
}

// CONVERSIÓN DE DATOS
echo "<br>=== CONVERSIÓN DE DATOS ===<br>";

// String a Integer
$numero_string = "123";
$numero_convertido = (int)$numero_string;
echo "String a Integer: " . $numero_convertido . " (tipo: " . gettype($numero_convertido) . ")<br>";

// Float a Integer
$float_numero = 3.99;
$float_convertido = (int)$float_numero;
echo "Float a Integer: " . $float_convertido . " (tipo: " . gettype($float_convertido) . ")<br>";

// Integer a String
$numero = 456;
$string_convertido = (string)$numero;
echo "Integer a String: " . $string_convertido . " (tipo: " . gettype($string_convertido) . ")<br>";

// Boolean a String
$bool = true;
$bool_string = (string)$bool;
echo "Boolean a String: " . $bool_string . " (tipo: " . gettype($bool_string) . ")<br>";

// Array a Object
$array_persona = ["nombre" => "Pedro", "edad" => 35];
$obj_persona = (object)$array_persona;
echo "Array a Object:<br>";
print_r($obj_persona);

// Verificación de tipos
echo "<center><br>=== VERIFICACIÓN DE TIPOS ===</center><br>";
echo "¿Es string? " . is_string($string) . "<br>";
echo "¿Es integer? " . is_int($entero) . "<br>";
echo "¿Es float? " . is_float($float) . "<br>";
echo "¿Es boolean? " . is_bool($bool_true) . "<br>";
echo "¿Es null? " . is_null($nulo) . "<br>";
echo "¿Es array? " . is_array($frutas) . "<br>";
echo "¿Es objeto? " . is_object($persona) . "<br>";

?>