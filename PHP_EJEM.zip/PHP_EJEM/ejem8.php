<?php
// Ejemplo con for
echo "1. Ciclo for:<br>";
for ($i = 1; $i <= 5; $i++) {
    echo "Número: $i<br>";
}

// Ejemplo con foreach
echo "<br>2. Ciclo foreach:<br>";
$frutas = ["manzana", "pera", "uva", "naranja"];
foreach ($frutas as $fruta) {
    echo "Fruta: $fruta<br>";
}

// Ejemplo con while
echo "<br>3. Ciclo while:<br>";
$contador = 1;
while ($contador <= 5) {
    echo "Contador: $contador<br>";
    $contador++;
}

// Ejemplo con do...while
echo "<br>4. Ciclo do...while:<br>";
$numero = 1;
do {
    echo "Número: $numero<br>";
    $numero++;
} while ($numero <= 5);

// Ejemplo de break
echo "<br>5. Uso de break:<br>";
for ($i = 1; $i <= 10; $i++) {
    if ($i == 6) {
        break; // Sale del ciclo cuando i es 6
    }
    echo "Valor: $i<br>";
}

// Ejemplo de continue
echo "<br>6. Uso de continue:<br>";
for ($i = 1; $i <= 5; $i++) {
    if ($i == 3) {
        continue; // Salta la iteración cuando i es 3
    }
    echo "Valor: $i<br>";
}
?>