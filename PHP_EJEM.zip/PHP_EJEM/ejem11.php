<?php
// Definición de la clase Persona
class Persona {
    // Atributos de la clase
    private $nombre;
    private $edad;
    private $genero;

    // Constructor de la clase
    public function __construct($nombre, $edad, $genero) {
        $this->nombre = $nombre;
        $this->edad = $edad;
        $this->genero = $genero;
    }

    // Métodos de la clase
    public function saludar() {
        echo "¡Hola, mi nombre es " . $this->nombre . "!<br>";
    }

    public function cumplirAnios() {
        $this->edad++;
        echo $this->nombre . " acaba de cumplir " . $this->edad . " años.<br>";
    }

    public function getInformacion() {
        return "Nombre: " . $this->nombre . ", Edad: " . $this->edad . ", Género: " . $this->genero . "<br>";
    }
}

// Creación de instancias (objetos) de la clase Persona
$persona1 = new Persona("Kaleth", 19, "Masculino");
$persona2 = new Persona("Adriana", 6, "Femenino");

// Uso de los objetos
$persona1->saludar();
$persona2->saludar();

$persona1->cumplirAnios();
$persona2->cumplirAnios();

echo $persona1->getInformacion();
echo $persona2->getInformacion();
?>