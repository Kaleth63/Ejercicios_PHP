<?php
echo "=== SENTENCIAS CONDICIONALES ===<br><br>";

// IF - ELSE IF - ELSE
echo "1. IF - ELSE IF - ELSE<br>";
$edad = 25;
$tiene_licencia = true;

if ($edad < 16) {
    echo "Eres menor de edad, no puedes conducir<br>";
} else if ($edad < 18) {
    echo "Puedes obtener un permiso de aprendiz<br>";
} else {
    if ($tiene_licencia) {
        echo "Puedes conducir, tienes edad y licencia<br>";
    } else {
        echo "Necesitas obtener tu licencia<br>";
    }
}

// IF con múltiples condiciones
echo "<br>2. IF CON MÚLTIPLES CONDICIONES<br>";
$hora = 14;
$dia_laboral = true;
$es_feriado = false;

if ($hora >= 9 && $hora <= 18 && $dia_laboral && !$es_feriado) {
    echo "Estamos en horario laboral<br>";
} else {
    echo "Estamos fuera de horario laboral<br>";
}

// SWITCH
echo "<br>3. SWITCH<br>";
$dia = 3;
switch ($dia) {
    case 1:
        echo "Lunes<br>";
        break;
    case 2:
        echo "Martes<br>";
        break;
    case 3:
        echo "Miércoles<br>";
        break;
    case 4:
        echo "Jueves<br>";
        break;
    case 5:
        echo "Viernes<br>";
        break;
    case 6:
    case 7:
        echo "Es fin de semana<br>";
        break;
    default:
        echo "Día no válido<br>";
}

// SWITCH con expresiones
echo "<br>4. SWITCH CON EXPRESIONES<br>";
$calificacion = 85;
switch (true) {
    case ($calificacion >= 90):
        echo "Sobresaliente<br>";
        break;
    case ($calificacion >= 80):
        echo "Notable<br>";
        break;
    case ($calificacion >= 70):
        echo "Bien<br>";
        break;
    case ($calificacion >= 60):
        echo "Suficiente<br>";
        break;
    default:
        echo "Insuficiente<br>";
}

// OPERADOR TERNARIO
echo "<br>5. OPERADOR TERNARIO<br>";
$edad = 20;
$puede_votar = ($edad >= 18) ? "Sí puede votar" : "No puede votar";
echo "¿Puede votar? $puede_votar<br>";

// Ternario anidado
$puntuacion = 75;
$resultado = ($puntuacion >= 90) ? "Excelente" :
    ($puntuacion >= 80 ? "Muy Bueno" :
        ($puntuacion >= 70 ? "Bueno" : "Regular"));
echo "Resultado: $resultado<br>";

// NULL COALESCE (??)
echo "<br>6. NULL COALESCE<br>";
$nombre = null;
$nombre_usuario = null;
$nombre_defecto = "Invitado";

// Usa el primer valor que no sea null
$nombre_mostrar = $nombre ?? $nombre_usuario ?? $nombre_defecto;
echo "Bienvenido, $nombre_mostrar<br>";

// Ejemplo práctico con arrays
$config = [
    "color" => "azul",
    "tamaño" => null,
    "formato" => ""
];

$color_elegido = $config["color"] ?? "negro";
$tamaño_elegido = $config["tamaño"] ?? "mediano";
$formato_elegido = $config["formato"] ?? "estándar";

echo "Configuración: color=$color_elegido, tamaño=$tamaño_elegido, formato=$formato_elegido<br>";

// OPERADOR SPACESHIP (<=>)
echo "<br>7. OPERADOR SPACESHIP<br>";
// Retorna -1 si el valor de la izquierda es menor
// Retorna 0 si los valores son iguales
// Retorna 1 si el valor de la izquierda es mayor

echo "Comparando números:<br>";
echo "5 <=> 3: " . (5 <=> 3) . "<br>";    // 1
echo "3 <=> 5: " . (3 <=> 5) . "<br>";    // -1
echo "5 <=> 5: " . (5 <=> 5) . "<br>";    // 0

echo "<br>Comparando strings:<br>";
echo "'a' <=> 'b': " . ('a' <=> 'b') . "<br>";    // -1
echo "'b' <=> 'a': " . ('b' <=> 'a') . "<br>";    // 1
echo "'a' <=> 'a': " . ('a' <=> 'a') . "<br>";    // 0

// Uso práctico del operador spaceship para ordenamiento
$frutas = ['manzana', 'banana', 'naranja'];
usort($frutas, function ($a, $b) {
    return $a <=> $b;
});
echo "<br>Frutas ordenadas: " . implode(', ', $frutas) . "<br>";

// Combinando operadores
echo "<br>8. COMBINANDO OPERADORES<br>";
$edad = 25;
$membresia = "premium";
$descuento = null;

// Combinando ternario con null coalesce
$precio_final = ($edad < 18) ? 10 :
    ($membresia === "premium" ? 15 : 20);
$descuento_aplicado = $descuento ?? 0;

echo "Precio final: $precio_final<br>";
echo "Descuento aplicado: $descuento_aplicado<br>";

?>