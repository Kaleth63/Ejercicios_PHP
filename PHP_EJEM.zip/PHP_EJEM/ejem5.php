<?php
// DECLARACIÓN DE FUNCIONES
declare(strict_types=1);
echo "=== FUNCIONES ===<br>";

// Función básica
function saludar($nombre) {
    echo "¡Hola, $nombre!<br>";
}

saludar("Juan");

// Función con parámetros por defecto
function calcularArea($ancho, $alto, $unidad = "cm") {
    $area = $ancho * $alto;
    echo "El área es $area $unidad^2<br>";
}

calcularArea(5, 10);      // Usa el valor por defecto de "cm"
calcularArea(3, 4, "m");  // Especifica la unidad "m"

// Función con parámetros por referencia
function incrementar(&$valor) {
    $valor++;
}

$numero = 5;
echo "Número inicial: $numero<br>";
incrementar($numero);
echo "Número después de incrementar: $numero<br>";

// Función con tipado fuerte


function sumarNumeros(int $a, int $b): int {
    return $a + $b;
}

try {
    echo "Suma de 5 + 3: " . sumarNumeros(5, 3) . "<br>";
    // Esto generará un error debido a strict_types=1
    echo sumarNumeros(5, 3);
} catch (TypeError $e) {
    echo "Error de tipo: " . $e->getMessage() . "<br>";
}

// Función con argumentos variables
function imprimirMensajes($mensaje, ...$nombres) {
    echo "<br>$mensaje: ";
    foreach ($nombres as $nombre) {
        echo "$nombre, ";
    }
    echo "<br>";
}

imprimirMensajes("Hola", "Juan", "María", "Pedro");
imprimirMensajes("Adiós", "Ana", "Luis");

// Función con retorno
function obtenerNombreCompleto($nombre, $apellido): string {
    $nombreCompleto = "$nombre $apellido";
    return $nombreCompleto;
}

$nombreCompleto = obtenerNombreCompleto("Santi", "Valderrama");
echo "Nombre completo: $nombreCompleto<br>";