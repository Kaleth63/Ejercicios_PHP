<?php
$config = [
    'db_host' => 'localhost',
    'db_user' => 'usuario',
    'db_pass' => 'contraseña'
];
?>