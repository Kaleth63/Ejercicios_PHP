<?php
// COMENTARIOS
// Esto es un comentario de una línea

/*
   Esto es un comentario
   de múltiples líneas
*/

# También se puede comentar así

// ====== ARRAYS ======
echo "=== ARRAYS INDEXADOS ===<br>";
// Array indexado
$frutas = ["manzana", "pera", "uva", "naranja"];
echo "Accediendo a elementos:<br>";
echo "Primera fruta: " . $frutas[0] . "<br>";
echo "Segunda fruta: " . $frutas[1] . "<br>";

// Agregar elementos
$frutas[] = "piña";  // Agrega al final
array_push($frutas, "mango");  // Otra forma de agregar

// Recorrer array indexado
echo "<br>Recorriendo array indexado:<br>";
for($i = 0; $i < count($frutas); $i++) {
    echo "Índice $i: " . $frutas[$i] . "<br>";
}

echo "<br>=== ARRAYS ASOCIATIVOS ===<br>";
// Array asociativo
$estudiante = [
    "nombre" => "Juan Pérez",
    "edad" => 20,
    "carrera" => "Informática",
    "promedio" => 8.5
];

// Acceder a elementos
echo "Nombre: " . $estudiante["nombre"] . "<br>";
echo "Edad: " . $estudiante["edad"] . "<br>";

// Agregar/modificar elementos
$estudiante["ciudad"] = "Madrid";
$estudiante["edad"] = 21;  // Modificar valor existente

// Recorrer array asociativo
echo "<br>Recorriendo array asociativo:<br>";
foreach($estudiante as $clave => $valor) {
    echo "$clave: $valor<br>";
}

echo "<br>=== ARRAYS MULTIDIMENSIONALES ===<br>";
// Array multidimensional
$escuela = [
    "Matemáticas" => [
        "profesor" => "María López",
        "alumnos" => ["Ana", "Pedro", "Luis"],
        "horario" => ["Lunes" => "8:00", "Miércoles" => "10:00"]
    ],
    "Historia" => [
        "profesor" => "Carlos Ruiz",
        "alumnos" => ["Juan", "Elena", "Miguel"],
        "horario" => ["Martes" => "9:00", "Jueves" => "11:00"]
    ]
];

// Acceder a elementos multidimensionales
echo "<br>Profesor de Matemáticas: " . $escuela["Matemáticas"]["profesor"] . "<br>";
echo "Primer alumno de Historia: " . $escuela["Historia"]["alumnos"][0] . "<br>";
echo "Horario Matemáticas Lunes: " . $escuela["Matemáticas"]["horario"]["Lunes"] . "<br>";

// Recorrer array multidimensional
echo "<br>Recorriendo array multidimensional:<br>";
foreach($escuela as $materia => $datos) {
    echo "<br>Materia: $materia<br>";
    echo "Profesor: " . $datos["profesor"] . "<br>";
    echo "Alumnos: " . implode(", ", $datos["alumnos"]) . "<br>";
    echo "Horarios:<br>";
    foreach($datos["horario"] as $dia => $hora) {
        echo "- $dia: $hora<br>";
    }
}

echo "<br>=== CONCATENACIÓN DE VALORES ===<br>";
// Concatenación con punto (.)
$nombre = "María";
$apellido = "González";
echo "Nombre completo: " . $nombre . " " . $apellido . "<br>";

// Concatenación en strings con comillas dobles
$edad = 25;
echo "La edad de $nombre es $edad años<br>";

// Concatenación con arrays
$info = $nombre . " tiene " . $estudiante["carrera"] . " como carrera<br>";
echo $info;

echo "<br>=== OPERADORES ===<br>";
// Operadores Aritméticos
echo "Operadores Aritméticos:<br>";
$a = 10;
$b = 3;
echo "a = $a, b = $b<br>";
echo "Suma: " . ($a + $b) . "<br>";          // 13
echo "Resta: " . ($a - $b) . "<br>";         // 7
echo "Multiplicación: " . ($a * $b) . "<br>"; // 30
echo "División: " . ($a / $b) . "<br>";       // 3.33...
echo "Módulo: " . ($a % $b) . "<br>";        // 1
echo "Exponente: " . ($a ** $b) . "<br>";     // 1000

// Operadores de Asignación
echo "\nOperadores de Asignación:<br>";
$x = 5;
echo "Inicial x = $x<br>";
$x += 3;    // x = x + 3
echo "Después de += 3: $x<br>";
$x -= 2;    // x = x - 2
echo "Después de -= 2: $x<br>";
$x *= 4;    // x = x * 4
echo "Después de *= 4: $x<br>";

// Operadores de Comparación
echo "<br>Operadores de Comparación:<br>";
$p = 5;
$q = "5";
echo "p = $p (integer), q = '$q' (string)<br>";
echo "p == q: " . var_export($p == $q, true) . "<br>";   // true
echo "p === q: " . var_export($p === $q, true) . "<br>"; // false
echo "p != q: " . var_export($p != $q, true) . "<br>";   // false
echo "p !== q: " . var_export($p !== $q, true) . "<br>"; // true

// Operadores Lógicos
echo "<br>Operadores Lógicos:<br>";
$verdadero = true;
$falso = false;
echo "AND (&&): " . var_export($verdadero && $falso, true) . "<br>";
echo "OR (||): " . var_export($verdadero || $falso, true) . "<br>";
echo "NOT (!): " . var_export(!$verdadero, true) . "<br>";

// Operadores de Incremento/Decremento
echo "<br>Operadores de Incremento/Decremento:<br>";
$i = 5;
echo "Inicial i = $i<br>";
echo "Postincremento (i++): " . $i++ . "<br>"; // Muestra 5, luego incrementa
echo "Después del incremento: $i<br>";         // Muestra 6
echo "Predecremento (--i): " . --$i . "<br>";  // Decrementa primero, muestra 5

// Operador de Concatenación de Arrays
echo "<br>Operador de Concatenación de Arrays:<br>";
$array1 = [1, 2, 3];
$array2 = [4, 5, 6];
$arrayCombinado = $array1 + $array2;
echo "Array combinado: ";
print_r($arrayCombinado);

?>