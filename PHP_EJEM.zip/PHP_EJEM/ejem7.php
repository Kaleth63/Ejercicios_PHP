<?php
echo "=== MANEJO DE ERRORES Y EXCEPCIONES ===<br><br>";

// 1. Ejemplo básico de try-catch
echo "1. MANEJO BÁSICO DE EXCEPCIONES<br>";
function dividir($numerador, $denominador) {
    if ($denominador === 0) {
        throw new Exception("Error: No se puede dividir por cero");
    }
    return $numerador / $denominador;
}

try {
    $resultado = dividir(10, 0);
    echo "El resultado es: $resultado<br>";
} catch (Exception $e) {
    echo "Se produjo un error: " . $e->getMessage() . "<br>";
    echo "En el archivo: " . $e->getFile() . "<br>";
    echo "En la línea: " . $e->getLine() . "<br>";
}

// 2. Múltiples tipos de excepciones
echo "<br>2. MÚLTIPLES EXCEPCIONES<br>";

class ValidacionException extends Exception {}
class BaseDatosException extends Exception {}

function validarUsuario($edad, $nombre) {
    if ($edad < 0) {
        throw new ValidacionException("La edad no puede ser negativa");
    }
    if (empty($nombre)) {
        throw new ValidacionException("El nombre no puede estar vacío");
    }
    // Simulamos error de base de datos
    if (strlen($nombre) > 50) {
        throw new BaseDatosException("Error al conectar con la base de datos");
    }
}

try {
    validarUsuario(-5, "Juan");
} catch (ValidacionException $e) {
    echo "Error de validación: " . $e->getMessage() . "<br>";
} catch (BaseDatosException $e) {
    echo "Error de base de datos: " . $e->getMessage() . "<br>";
} catch (Exception $e) {
    echo "Error general: " . $e->getMessage() . "<br>";
}

// 3. Try-catch con finally
echo "<br>3. USO DE FINALLY<br>";

function procesarArchivo($nombreArchivo) {
    $archivo = null;
    try {
        echo "Intentando abrir archivo...<br>";
        if (!file_exists($nombreArchivo)) {
            throw new Exception("El archivo no existe");
        }
        $archivo = fopen($nombreArchivo, 'r');
        echo "Procesando archivo...<br>";
        throw new Exception("Error al procesar el archivo");
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage() . "<br>";
    } finally {
        if ($archivo) {
            echo "Cerrando archivo...<br>";
            fclose($archivo);
        }
        echo "Limpieza completada<br>";
    }
}

procesarArchivo("archivo_inexistente.txt");

// 4. Excepciones personalizadas con métodos adicionales
echo "<br>4. EXCEPCIONES PERSONALIZADAS<br>";

class ProductoException extends Exception {
    private $codigoProducto;

    public function __construct($mensaje, $codigo = 0, $codigoProducto = '') {
        parent::__construct($mensaje, $codigo);
        $this->codigoProducto = $codigoProducto;
    }

    public function getCodigoProducto() {
        return $this->codigoProducto;
    }
}

class Producto {
    private $codigo;
    private $stock;

    public function __construct($codigo, $stock) {
        $this->codigo = $codigo;
        $this->stock = $stock;
    }

    public function restarStock($cantidad) {
        if ($cantidad <= 0) {
            throw new ProductoException(
                "La cantidad debe ser positiva",
                1,
                $this->codigo
            );
        }
        if ($cantidad > $this->stock) {
            throw new ProductoException(
                "Stock insuficiente",
                2,
                $this->codigo
            );
        }
        $this->stock -= $cantidad;
        echo "Stock actualizado correctamente<br>";
    }
}

try {
    $producto = new Producto("PROD001", 5);
    $producto->restarStock(-1);
} catch (ProductoException $e) {
    echo "Error en producto " . $e->getCodigoProducto() . ": " .
        $e->getMessage() . " (Código: " . $e->getCode() . ")<br>";
}

// 5. Captura y relanzamiento de excepciones
echo "<br>5. RELANZAMIENTO DE EXCEPCIONES<br>";

function validarDatos($datos) {
    try {
        if (empty($datos)) {
            throw new Exception("Datos vacíos");
        }
        if (!is_array($datos)) {
            throw new Exception("Se esperaba un array");
        }
    } catch (Exception $e) {
        // Loggeamos el error original
        echo "Log: " . $e->getMessage() . "<br>";
        // Relanzamos una nueva excepción
        throw new Exception("Error en la validación de datos: " . $e->getMessage());
    }
}

try {
    validarDatos(null);
} catch (Exception $e) {
    echo "Error capturado: " . $e->getMessage() . "<br>";
}

// 6. Try anidados
echo "<br>6. TRY ANIDADOS<br>";

function operacionCompleja() {
    try {
        try {
            throw new Exception("Error en operación interna");
        } catch (Exception $e) {
            echo "Captura interna: " . $e->getMessage() . "<br>";
            throw new Exception("Error en operación externa", 0, $e);
        }
    } catch (Exception $e) {
        echo "Captura externa: " . $e->getMessage() . "<br>";
        echo "Causa original: " . $e->getPrevious()->getMessage() . "<br>";
    }
}

operacionCompleja();

?>