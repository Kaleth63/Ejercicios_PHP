<?php
echo "En este archivo estan todos los ejercicios faltantes del punto 10 desde Constantes de Clase, Autocarga de Clases.", "<br><br>";
// Archivo: Persona.php
class Persona {
    public const ESPECIE = 'Homo Sapiens';

    private $nombre;
    private $edad;

    public function __construct($nombre, $edad) {
        $this->nombre = $nombre;
        $this->edad = $edad;
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function getEdad() {
        return $this->edad;
    }
}

// Archivo: Estudiante.php
class Estudiante extends Persona {
    private $carrera;

    public function __construct($nombre, $edad, $carrera) {
        parent::__construct($nombre, $edad);
        $this->carrera = $carrera;
    }

    public function __destruct() {
        echo "El estudiante " . $this->getNombre() . " ha sido destruido.<br>";
    }

    protected function estudiar() {
        echo $this->getNombre() . " está estudiando la carrera de " . $this->carrera . ".<br>";
    }

    public function aprobarExamen() {
        $this->estudiar();
        echo $this->getNombre() . " ha aprobado el examen.<br>";
    }
}

// Archivo: Animal.php
abstract class Animal {
    protected $nombre;

    public function __construct($nombre) {
        $this->nombre = $nombre;
    }

    abstract public function hacerSonido();

    public function getNombre() {
        return $this->nombre;
    }
}

interface Volador {
    public function volar();
}

// Archivo: Loro.php
class Loro extends Animal implements Volador {
    public function hacerSonido() {
        echo "¡Pio pio!<br>";
    }

    public function volar() {
        echo $this->nombre . " está volando.<br>";
    }
}

// Archivo: index.php
spl_autoload_register(function ($class) {
    require_once "$class.php";
});

// Ejemplos de uso
$persona = new Persona('Juan', 30);
echo "Nombre: " . $persona->getNombre() . "<br>";
echo "Edad: " . $persona->getEdad() . "<br>";
echo "Especie: " . Persona::ESPECIE . "<br>";

$estudiante = new Estudiante('María', 22, 'Ingeniería de Sistemas');
$estudiante->aprobarExamen();

$loro = new Loro('Pepe');
$loro->hacerSonido();
$loro->volar();