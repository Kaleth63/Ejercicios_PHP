<?php
function saludar($nombre) {
    return "¡Hola, $nombre!";
}
?>