<?php
$menu = [
    'inicio' => 'index.php',
    'contacto' => 'contacto.php',
    'about' => 'about.php'
];
?>
